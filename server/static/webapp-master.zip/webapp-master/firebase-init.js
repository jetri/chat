// Get these values for your project from the https://console.firebase.google.com/
const FIREBASE_INIT = {
  // Project Settings -> Cloud Messaging, "Sender ID".
  messagingSenderId: "114126160546",
  // Project Settings -> Cloud Messaging -> Web configuration -> Web Push certificates.
  // This value IS NOT included in the generated js config you can download from
  // the firebase console. It needs to be added separately.
  messagingVapidKey: "BOgQVPOMzIMXUpsYGpbVkZoEBc0ifKY_f2kSU5DNDGYI6i6CoKqqxDd7w7PJ3FaGRBgVGJffldETumOx831jl58"
};
